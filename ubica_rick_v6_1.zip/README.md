# Raptor Rutas (UBICA-RICK v6.1) - Sistema de Campo y Recuperación Vehicular

Aplicación web progresiva (PWA) optimizada para patrullaje y recuperación vehicular en Medellín y el Valle de Aburrá (Antioquia).

---

## 🆕 Novedades de la Versión 6.1

### 1. Panel de Administración: Monitoreo de Operadores Conectados en Tiempo Real
- **Pestaña "🟢 Conectados en Vivo"**: Permite al administrador visualizar instantáneamente quién está conectado en el terreno, hora exacta del último reporte y coordenadas GPS activas.
- **Heartbeat / Latido Automático**: Los operadores activos emiten un latido de presencia cada 12 segundos con sincronización en Firestore y respaldo en caché local.
- **Interruptor de Acceso Inmediato**: El administrador puede apagar o encender el acceso al mapa de cualquier operador con un solo toque desde la lista de presencia o desde el gestor de usuarios.

### 2. Bloqueo Estricto y Pantalla Exclusiva de Inicio de Sesión
- **Protección Total del Mapa**: Cuando un usuario no ha iniciado sesión o su cuenta ha sido desactivada/apagada por el administrador, el mapa (`#map`), la barra superior y los botones flotantes se ocultan por completo (`display: none; visibility: hidden;`).
- **Vista Limpia de Acceso**: Únicamente se despliega la tarjeta de autenticación solicitando Usuario y Contraseña/PIN, impidiendo cualquier visualización de placas o coordenadas confidenciales.
- **Aviso Informativo Claro**: Si el operador fue desactivado, la pantalla de inicio de sesión le informa con un aviso destacado: *"🔒 ACCESO APAGADO: Tu usuario ha sido desactivado por el administrador"*.

### 3. Radar Flotante PiP en Tiempo Real Continuo (Sin Congelamiento)
- **Doble Motor de Actualización GPS**:
  - `navigator.geolocation.watchPosition` con `maximumAge: 0` y `timeout: 5000`.
  - **Sondeo Activo de Hardware** (`forzarLecturaGPSHardware`) cada 1200 ms forzando lecturas directas del sensor GPS, incluso si el dispositivo móvil intenta optimizar batería o ralentizar temporizadores de fondo.
- **Watchdog de Reconexión Automática**: Si el navegador no recibe coordenadas durante más de 5 segundos, el sistema reinicia el receptor GPS de manera transparente.
- **Cálculo Activo de Distancia por Cuadro**: El visor flotante (Picture-in-Picture) y el panel superior recalculan la distancia métrica precisa en cada ciclo (500 ms) contra la posición del operador en movimiento, garantizando una cuenta regresiva fluida a medida que se aproxima a la placa objetivo.

---

## 🚀 Despliegue en GitHub Pages (Paso a Paso)

1. **Nombre obligatorio del archivo:**
   - El archivo principal debe llamarse **estrictamente `index.html`** (en minúsculas, sin espacios ni paréntesis como `(1)`, `(2)`, etc.).
2. **Subida a GitHub:**
   - Ingresa a tu repositorio: `https://github.com/rikardorodriiguez-art/ruta-campo`
   - Haz clic en **Add file** > **Upload files**.
   - Arrastra el archivo `index.html` y pulsa **Commit changes**.
3. **Verificación en el navegador:**
   - GitHub Pages compila los cambios en 30-90 segundos.
   - Abre tu enlace: `https://rikardorodriiguez-art.github.io/ruta-campo/index.html`
   - Presiona **Ctrl + F5** (o **Ctrl + Shift + R**) para refrescar la caché del navegador.

---

## ✨ Funcionalidades Principales

- **Mapas de Alta Disponibilidad:** Capa principal oficial de **Google Maps** (sin bloqueos 403), selector de capas CartoDB Voyager HD y Satélite Híbrido.
- **Seguimiento GPS en Tiempo Real:** Marcador azul pulsante (`🔵 Mi Ubicación Actual`) con centrado rápido (`🎯`).
- **Control de Radar On/Off:** Alternancia visual con alertas sonoras, vibración y visor flotante en miniatura (Picture-in-Picture).
- **Ruta de Corredor Vial (≤ 500 m):** Trazado de ruta entre dos puntos con desvío inteligente hacia placas ubicadas a menos de 500 metros del trayecto.
- **Borrado Masivo con Historial:** Eliminación por lista de placas con informe detallado y advertencia en caso de intentar re-agregar una placa eliminada previamente.
- **Reactivación Automática de Placas Visitadas:** Las placas marcadas como visitadas vuelven a sonar en el radar tras 3 horas de transcurrida la visita.
- **Mantener Pantalla Encendida:** Interruptor `💡 Pantalla` con Screen Wake Lock API.
