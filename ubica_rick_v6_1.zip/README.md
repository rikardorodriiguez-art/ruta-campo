# Raptor Rutas (UBICA-RICK v6.2) - Sistema de Campo y Recuperación Vehicular

Aplicación web progresiva (PWA) optimizada para patrullaje y recuperación vehicular en Medellín y el Valle de Aburrá (Antioquia).

## 🆕 Novedades de la Versión 6.2

### 1. Desaturación Visual de la Barra Superior

* **Barra Superior Ultra Limpia**: Se redujo la fila superior de más de 10 botones acumulados a únicamente **4 elementos clave**:

  1. `[👑 Perfil Activo]`: Indica quién está conduciendo y permite abrir el perfil o cerrar sesión.

  2. `[💡 Pantalla]`: Mantiene la pantalla encendida (Wake Lock) en ruta.

  3. `[🚨 Radar]`: Activa y desactiva el radar de proximidad con HUD flotante.

  4. `[🛠️ Menú]`: Abre el cajón organizado de capas, herramientas y configuración.

* **Retiro Temporal de SOS**: El botón de pánico SOS se retiró de la barra superior para evitar pulsaciones accidentales mientras se conduce la moto.

### 2. Agrupación Estructurada del Menú de Herramientas

Al pulsar **`🛠️ Menú`**, todas las funciones quedan organizadas en 3 bloques limpios y accesibles:

* **🗺️ Capas del Mapa:**

  * `🌙 Modo Noche (AMOLED Batería)`: Conmuta a mapa oscuro de alto contraste y ultra ahorro de batería.

  * `🔥 Mapa de Calor (Concentración)`: Muestra las zonas calientes con mayor densidad de placas por recuperar.

  * `🏍️ Motos en Vivo (Tracking Equipo)`: Muestra la ubicación de tu moto y la de tus compañeros en tiempo real.

* **🧭 Rutas y Gestión:**

  * `🧭 Centro de Rutas`: Acceso a rutas inteligentes (Cercanía 1 a 1, Corredor vial a 500 m, Multi-parada secuencial).

  * `📑 Cierre de Turno`: Reporte diario de placas visitadas, kilómetros recorridos y novedades para exportación.

  * `📥 Importar Excel`: Carga masiva de placas desde archivos `.xlsx`.

* **⚙️ Sistema:**

  * `🟢 Modo Edición / 🔴 Modo Moto`: Alterna entre edición libre de pines y modo conducción seguro (bloqueo táctil accidental).

  * `📱 Instalar App`: Instalación como PWA nativa en la pantalla de inicio del teléfono.

  * `👥 Control de Usuarios`: Panel administrativo para gestión de operadores, contraseñas y permisos.

### 3. Corrección Operativa de Botones

#### 🌙 Modo Noche (AMOLED)

* **Problema previo**: La capa diurna de Google Maps permanecía fija bajo el mapa o entraba en conflicto con los mosaicos oscuros.

* **Solución implementada**: Ahora al pulsar `🌙 Modo Noche`, el sistema retira explícitamente cualquier capa base activa (`capaGoogle`, `capaCarto`, etc.), inyecta los mosaicos CartoDB DarkMatter de alto contraste, cambia el fondo a negro puro (`#000000`) para apagar píxeles OLED en pantalla, y al pulsar nuevamente restablece Google Maps con suavidad.

#### 🏍️ Motos en Vivo (Tracking de Flota)

* **Problema previo**: No existía una suscripción activa a la colección de Firestore `presencia_operadores`, por lo que la caché de motorizados permanecía vacía y al pulsar el botón no se dibujaban marcadores en el mapa.

* **Solución implementada**:

  * Se vinculó el listener en tiempo real `onSnapshot` sobre `presencia_operadores`.

  * Ahora al activar la capa se dibuja de inmediato tu propia moto (`🏍️ Mi Moto [Nombre]`) en verde esmeralda y las motos de tus compañeros (`🏍️ [Nombre]`) en azul celeste.

  * Cada marcador incluye popup con usuario, hora del último reporte GPS, coordenadas exactas y botón de navegación directa hacia su posición vía Google Maps / Waze.

## 🚀 Despliegue en GitHub Pages (Paso a Paso)

1. **Nombre obligatorio del archivo:**

   * El archivo principal debe llamarse **estrictamente `index.html`** (en minúsculas, sin espacios ni paréntesis como `(1)`, `(2)`, etc.).

2. **Subida a GitHub:**

   * Ingresa a tu repositorio: `https://github.com/rikardorodriiguez-art/ruta-campo`

   * Haz clic en **Add file** > **Upload files**.

   * Arrastra el archivo `index.html` y pulsa **Commit changes**.

3. **Verificación en el navegador:**

   * GitHub Pages compila los cambios en 30-90 segundos.

   * Abre tu enlace: `https://rikardorodriiguez-art.github.io/ruta-campo/index.html`

   * Presiona **Ctrl + F5** (o **Ctrl + Shift + R**) para refrescar la caché del navegador.